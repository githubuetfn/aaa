<?php
date_default_timezone_set('Asia/Baghdad');
if(isset($update->callback_query)) {
          $chatiId = $update->callback_query->message->chat->id;
   
}
$xx1 = file_put_contents("V1","❌");
$xz1 = file_get_contents("V1");
$xx2 = file_put_contents("V2","❌");
$xz2 = file_get_contents("V2");
$xx3 = file_put_contents("V3","❌");
$xz3 = file_get_contents("V3");
$xx4 = file_put_contents("V4","❌");
$xz4 = file_get_contents("V4");
$xx5 = file_put_contents("V5","❌");
$xz5 = file_get_contents("V5");
$xx6 = file_put_contents("V6","❌");
$xz6 = file_get_contents("V6");
$loo1 =  file_get_contents("akil1/ID");
$toook = file_get_contents("akil1/token");
$loo2 =  file_get_contents("akil2/ID");
$toook2 = file_get_contents("akil2/token");
$loo3 =  file_get_contents("akil3/ID");
$toook3 = file_get_contents("akil3/token");
$loo4 =  file_get_contents("akil4/ID");
$toook4 = file_get_contents("akil4/token");
$loo5 =  file_get_contents("akil5/ID");
$toook5 = file_get_contents("akil5/token");
$loo6 =  file_get_contents("akil6/ID");
$toook6 = file_get_contents("akil6/token");
$akil967 = file_get_contents("akil");
if($xz1 == "❌"){
$akil967 = file_get_contents("akil");
system("cd akil1 ; screen -S nl$akil967 -X kill");
}
if($xz2 == "❌"){
$akil967 = file_get_contents("akil");
system("cd akil2 ; screen -S nl2$akil967 -X kill");
}
if($xz3 == "❌"){
$akil967 = file_get_contents("akil");
system("cd akil3 ; screen -S nl3$akil967 -X kill");
}
if($xz4 == "❌"){
$akil967 = file_get_contents("akil");
system("cd akil4 ; screen -S nl4$akil967 -X kill");
}
if($xz5 == "❌"){
$akil967 = file_get_contents("akil");
system("cd akil5 ; screen -S nl5$akil967 -X kill");
}
if($xz6 == "❌"){
$akil967 = file_get_contents("akil");
system("cd akil6 ; screen -S nl6$akil967 -X kill");
}
if (!file_exists("ID")) {

$gii = readline("admin id : ");


 file_put_contents("ID",$gii);

 }
 
if (!file_exists("token")) {
 $gii = readline("token  : ");
 file_put_contents("token",$gii);

}

if(!file_exists('config.json')){
	$token = file_get_contents('token');
	$id = file_get_contents('ID');
	file_put_contents('config.json', json_encode(['id'=>$id,'token'=>$token]));
	
}

	
	$fackfor = "fack For everyone who steals my file or changes rights\n";
    $fackfor2 = "ها بصرواي شفتك";
    echo $fackfor;
    echo $fackfor2;

		  $config = json_decode(file_get_contents('config.json'),1);
	$token = file_get_contents("token");
	$id = file_get_contents("ID");
	
   


if(!file_exists('accounts.json')){
    file_put_contents('accounts.json',json_encode([]));
}
include 'index.php';
try {
	$callback = function ($update, $bot) {
		global $id;
		if($update != null){
		  $config = json_decode(file_get_contents('config.json'),1);
		  $config['filter'] = $config['filter'] != null ? $config['filter'] : 1;
      $accounts = json_decode(file_get_contents('accounts.json'),1);
			if(isset($update->message)){
				$message = $update->message;
				$chatId = $message->chat->id;
				$text = $message->text;
				if($chatId == $id){
					if($text == '/start'){					                		
              $bot->sendphoto([
               'chat_id'=>$id,
                  'photo'=>"https://t.me/H5QQQ/59",
                   'caption'=> "𓊈 QEADE 𓊉 𓁹 التفعيل بواسطة @H5QQQ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'➕ اضافه حسابات وهميه ➕','callback_data'=>'login'],['text'=>'➖صفحه التحكم ➖','callback_data'=>'backakil']],
                       [['text'=>"قناتي ✔   ", 'url'=>"https://t.me/H5QQQ"],['text'=>"المطور ➿ ", 'url'=>"https://t.me/P4ORO"]],
                    
                      ]
                  ])
              ]);
}elseif(strpos($text,"/tok1")!==false and $chatId == $id){
						
$akilto1 = explode('/tok1 ',$text)[1];
	
						file_put_contents("akil1/token",$akilto1);
						$xz1 = file_get_contents("V1");
						$loo1 =  file_get_contents("akil1/ID");
                        $toook = file_get_contents("akil1/token");
                   $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                     'text'=> "البوت رقم 1
حاله التفعيل : $xz1 
ايدي الشخص : $loo1
توكن :  $toook ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo1x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko1x'],['text'=>"ايقاف ",'callback_data'=>'killx1']],
                  ]
                  ])
                  ]);



   	}elseif(strpos($text,"/akil1")!==false and $chatId == $id){
						
$akilv1 = explode('/akil1 ',$text)[1];
	
						                                
                    file_put_contents("akil1/ID",$akilv1);
                    $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 1
ارسل الأمر التالي الآن
/tok1 token
- استبدل كلمة token ب توكن الشخص الذي تريد تفعيل  البوت له",

						]);

   


}elseif(strpos($text,"/tok2")!==false and $chatId == $id){
						
$akilto2 = explode('/tok2 ',$text)[1];
	
						file_put_contents("akil2/token",$akilto2);
						$xz2 = file_get_contents("V2");
						$loo2 =  file_get_contents("akil2/ID");
                        $toook2 = file_get_contents("akil2/token");
                   $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                     'text'=> "البوت رقم 2
حاله التفعيل : $xz2 
ايدي الشخص : $loo2
توكن :  $toook2 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo2x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko2x'],['text'=>"ايقاف ",'callback_data'=>'killx2']],
                  ]
                  ])
                  ]);
   	}elseif(strpos($text,"/akil2")!==false and $chatId == $id){
						
$akilv2 = explode('/akil2 ',$text)[1];
	
						                                
                    file_put_contents("akil2/ID",$akilv2);
                    $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 2
ارسل الأمر التالي الآن
/tok2 token
- استبدل كلمة token ب توكن الشخص الذي تريد تفعيل  البوت له",

						]);

   



}elseif(strpos($text,"/tok3")!==false and $chatId == $id){
						
$akilto3 = explode('/tok3 ',$text)[1];
	
						file_put_contents("akil3/token",$akilto3);
						$xz3 = file_get_contents("V3");
						$loo3 =  file_get_contents("akil3/ID");
                        $toook3 = file_get_contents("akil3/token");
                   $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                     'text'=> "البوت رقم 3
حاله التفعيل : $xz3 
ايدي الشخص : $loo3
توكن :  $toook3 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo3x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko3x'],['text'=>"ايقاف ",'callback_data'=>'killx3']],
                  ]
                  ])
                  ]);
   	}elseif(strpos($text,"/akil3")!==false and $chatId == $id){
						
$akilv3 = explode('/akil3 ',$text)[1];
	
						                                
                    file_put_contents("akil3/ID",$akilv3);
                    $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 3
ارسل الأمر التالي الآن
/tok3 token
- استبدل كلمة token ب توكن الشخص الذي تريد تفعيل  البوت له",

						]);

   


}elseif(strpos($text,"/tok4")!==false and $chatId == $id){
						
$akilto4 = explode('/tok4 ',$text)[1];
	
						file_put_contents("akil4/token",$akilto4);
						$xz4 = file_get_contents("V4");
						$loo4 =  file_get_contents("akil4/ID");
                        $toook4 = file_get_contents("akil4/token");
                   $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                     'text'=> "البوت رقم 4
حاله التفعيل : $xz4 
ايدي الشخص : $loo4
توكن :  $toook4 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo4x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko4x'],['text'=>"ايقاف ",'callback_data'=>'killx4']],
                  ]
                  ])
                  ]);
   	}elseif(strpos($text,"/akil4")!==false and $chatId == $id){
						
$akilv4 = explode('/akil4 ',$text)[1];
	
						                                
                    file_put_contents("akil4/ID",$akilv4);
                    $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 4
ارسل الأمر التالي الآن
/tok4 token
- استبدل كلمة token ب توكن الشخص الذي تريد تفعيل  البوت له",

						]);

   


}elseif(strpos($text,"/tok5")!==false and $chatId == $id){
						
$akilto5 = explode('/tok5 ',$text)[1];
	
						file_put_contents("akil5/token",$akilto5);
						$xz5 = file_get_contents("V5");
						$loo5 =  file_get_contents("akil5/ID");
                        $toook5 = file_get_contents("akil5/token");
                   $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                     'text'=> "البوت رقم 5
حاله التفعيل : $xz5 
ايدي الشخص : $loo5
توكن :  $toook5 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo5x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko5x'],['text'=>"ايقاف ",'callback_data'=>'killx5']],
                  ]
                  ])
                  ]);
   	}elseif(strpos($text,"/akil5")!==false and $chatId == $id){
						
$akilv5 = explode('/akil5 ',$text)[1];
	
						                                
                    file_put_contents("akil5/ID",$akilv5);
                    $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 5
ارسل الأمر التالي الآن
/tok5 token
- استبدل كلمة token ب توكن الشخص الذي تريد تفعيل  البوت له",

						]);

   


}elseif(strpos($text,"/tok6")!==false and $chatId == $id){
						
$akilto6 = explode('/tok6 ',$text)[1];
	
						file_put_contents("akil6/token",$akilto6);
						$xz6 = file_get_contents("V6");
						$loo6 =  file_get_contents("akil6/ID");
                        $toook6 = file_get_contents("akil6/token");
                   $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                     'text'=> "البوت رقم 6
حاله التفعيل : $xz6 
ايدي الشخص : $loo6
توكن :  $toook6 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo6x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko6x'],['text'=>"ايقاف ",'callback_data'=>'killx6']],
                  ]
                  ])
                  ]);
   	}elseif(strpos($text,"/akil6")!==false and $chatId == $id){
						
$akilv6 = explode('/akil6 ',$text)[1];
	
						                                
                    file_put_contents("akil6/ID",$akilv6);
                    $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 6
ارسل الأمر التالي الآن
/tok6 token
- استبدل كلمة token ب توكن الشخص الذي تريد تفعيل  البوت له",

						]);

   



          } elseif($text != null){
          	if($config['mode'] != null){
          		$mode = $config['mode'];
          		if($mode == 'addL'){
          			$ig = new ig(['file'=>'','account'=>['useragent'=>'Instagram 27.0.0.7.97 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)']]);
          			list($user,$pass) = explode(':',$text);
          			list($headers,$body) = $ig->login($user,$pass);
          			// echo $body;
          			$body = json_decode($body);
          			if(isset($body->message)){
          				if($body->message == 'challenge_required'){
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'text'=>"لقد تم رفض الحساب لانه محظور او انه يطلب مصادقه⚙️"
          					]);
          				} else {
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'text'=>"كلمه السر او اليوزر خطأ ⛔"
          					]);
          				}
          			} elseif(isset($body->logged_in_user)) {
          				$body = $body->logged_in_user;
          				preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $headers, $matches);
								  $CookieStr = "";
								  foreach($matches[1] as $item) {
								      $CookieStr .= $item."; ";
								  }
          				$account = ['cookies'=>$CookieStr,'useragent'=>'Instagram 27.0.0.7.97 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)'];

          				$accounts[$text] = $account;
          				file_put_contents('accounts.json', json_encode($accounts));
          				$mid = $config['mid'];
          				$bot->sendMessage([
          				      'parse_mode'=>'markdown',
          							'chat_id'=>$chatId,
          							'text'=>"*تم اضافه حساب جديد الى الاداه 💣.*\n _Username_ : [$user])(instagram.com/$user)\n_Account Name_ : _{$body->full_name}_",
												'reply_to_message_id'=>$mid
          					]);
          				$keyboard = ['inline_keyboard'=>[
										[['text'=> "ضيف وهمي جديد ➕",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"تسجيل الخروج",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"اهلا عزيزي ✔️ في الاسفل هي حساباتك الوهميه المسجله في الاداة",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
		              $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          			}
          		}  elseif($mode == 'selectFollowers'){
          		  if(is_numeric($text)){
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>"تم التعديل.",
          		        'reply_to_message_id'=>$config['mid']
          		    ]);
          		    $config['filter'] = $text;
          		    $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                      'text'=>"التحكم بلبوت @H5QQQ ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'اضف حساب ','callback_data'=>'login']],
                          [['text'=>'✦ طرق سحب اليوزرات ✦','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 💀','callback_data'=>'run'],['text'=>'ايقاف الصيد💀','callback_data'=>'stop']],
                          [['text'=>'حاله الحسابات ⚒','callback_data'=>'status'],['text'=>'قسم خاص ✔','callback_data'=>'statusakil']],
                          [['text'=>' قناتي❗','url'=>'t.me/H5QQQ'],['text'=>'المطور❔','url'=>'t.me/AKIL22BOT']],
                      ]
                  ])
                  ]);
          		    $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          		  } else {
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>'- يرجى ارسال رقم فقط .'
          		    ]);
          		  }
          		} else {
          		  switch($config['mode']){
          		    case 'search':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php search.php');
          		      break;
          		      case 'followers':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php followers.php');
          		      break;
          		      case 'following':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php following.php');
          		      break;
          		      case 'hashtag':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php hashtag.php');
          		      break;
          		  }
          		}
          	}
          }
				} else {
				

                                                   
                                                         
                                                               
                                                                           
              
               
                
               $bot->sendMessage([
				
                			'chat_id'=>$chatId,
					
                					'text'=>"هذا البوت مدفوع و ليس مجاني 
يمكنك الحصول على نسخه من البوت بعد شرائه من المطور 
اضغط في الاسفل لمراسله المطور 👇",
				
                								'reply_markup'=>json_encode([
        
                								          'inline_keyboard'=>[
             
                								                   [['text'=>'اضغط لمراسله المطور 🗣','url'=>'t.me/H5QQQ']],
           
                								                              [['text'=>'اضغط هنا','callback_data'=>'akilm']]
          
                			       ]
 
                			   	])
                		
	]);
	               				
				
								
					
					
					
				
				
                      
					
				}
				
			} elseif(isset($update->callback_query)) {
          $chatId = $update->callback_query->message->chat->id;
          $mid = $update->callback_query->message->message_id;
          $text = $message->callback_query->text;
          $data = $update->callback_query->data;
          echo $data;
          
          
 
                           
          if($data == 'login' and $chatId == $id ){

        		$keyboard = ['inline_keyboard'=>[
									[['text'=>"ضيف وهمي جديد ➕",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"تسجيل الخروج",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']];
		              $bot->sendMessage([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                   'text'=>"اهلا عزيزي ✔️ في الاسفل هي حساباتك الوهميه المسجله في الاداة",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
		              
		} elseif($data == 'akilm'  ){
		  
		  
		  
		                       
          
     $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                      'text'=>"التحكم بلبوت @H5QQQ ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'قناتي','url'=>'t.me/H5QQQ'],['text'=>'تواصل','url'=>'t.me/AKIL22bot']],
                           [['text'=>'اشتراك بلبوت','url'=>'t.me/C_Y_L']],
                           [['text'=>'ملف البوت','callback_data'=>'akilf'],['text'=>'رجوع','callback_data'=>'hback']],
                           
 ]
                  ])
              ]);
				
		              
		              
		              
		                  } elseif($data == 'hback'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
					
                      'message_id'=>$mid,
                					'text'=>"هذا البوت مدفوع و ليس مجاني 
يمكنك الحصول على نسخه من البوت بعد شرائه من المطور 
اضغط في الاسفل لمراسله المطور 👇",
				
                								'reply_markup'=>json_encode([
        
                								          'inline_keyboard'=>[
             
                								                   [['text'=>'اضغط لمراسله المطور 🗣','url'=>'t.me/H5QQQ']],
           
                								                              [['text'=>'طلب اشتراك من الادمن','callback_data'=>'akilm']]
          
                			       ]
 
                			   	])
                		
	]);
	               				
				
								

		              
		              
		              
		              
		              
		              
		              
		              
		              
          } elseif($data == 'addL' and $chatId == $id ){

          	$config['mode'] = 'addL';
          	$config['mid'] = $mid;
          	file_put_contents('config.json', json_encode($config));
          	$bot->sendMessage([
          			'chat_id'=>$chatId,
          			'text'=>"ارسل الحساب بهذا الشكل 👈   `user:pass`",
          			'parse_mode'=>'markdown'
          	]);
          } elseif($data == 'grabber'){

            $for = $config['for'] != null ? $config['for'] : 'حدد الحساب';
            $count = count(explode("\n", file_get_contents($for)));
            $bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>'سحب من كلمات✨','callback_data'=>'search']],
                        [['text'=>'هاشتاج','callback_data'=>'hashtag'],['text'=>'📈 من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'Followers','callback_data'=>'followers'],['text'=>"Following",'callback_data'=>'following']],
                        [['text'=>"الحساب المحدد : $for",'callback_data'=>'for']],
                        [['text'=>'لسته يوزرات جديده ⚕️','callback_data'=>'newList'],['text'=>'لسته يوزرات سابقه ⚠️','callback_data'=>'append']],
                        [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']],
                    ]
                ])
            ]);
            
            
            
            } elseif($data == 'akilf'){
            
            
$bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                      'text'=>"https://t.me/H5QQQ/824",
            
            
                        ]);
            
            
            
            
            
            
            
            
            
            
          } elseif($data == 'search'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان قم بأرسال الكلمه التريد البحث عليها و ايضا يمكنك من استخدام اكثر من كلمه عن طريق وضع فواصل بين الكلمات⚔️"
            ]);
            $config['mode'] = 'search';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'followers'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان قم بأرسال اليوزر التريد سحب متابعيه و ايضا يمكنك من استخدام اكثر من يوزر عن طريق وضع فواصل بين اليوزرات 🔪"
            ]);
            $config['mode'] = 'followers';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'following'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان قم بأرسال اليوزر التريد سحب الذي  متابعهم و ايضا يمكنك من استخدام اكثر من يوزر عن طريق وضع فواصل بين اليوزرات 🔪"
            ]);
            $config['mode'] = 'following';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'hashtag'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان قم بأرسال الهاشتاك بدون علامه # يمكنك 🧿استخدام هاشتاك واحد فقط"
            ]);
            $config['mode'] = 'hashtag';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'newList'){
            file_put_contents('a','new');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"تم اختيار ⚕️ لستةة يوزرات جديده بنجاح",
							'show_alert'=>1
						]);
          } elseif($data == 'append' and $chatId == $id){
            file_put_contents('a', 'ap');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"تم اختيار ⚠️ لستةة يوزرات سابقه بنجاح",
							'show_alert'=>1
						]);

          } elseif($data == 'for'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'forg&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"اختار الحساب",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"قم بتسجيل حساب اولا ⛔",
							'show_alert'=>1
						]);
            }
          } elseif($data == 'selectFollowers'){
            bot('sendMessage',[
                'chat_id'=>$chatId,
                'text'=>'قم بأرسال عدد متابعين .'
            ]);
            $config['mode'] = 'selectFollowers';
          	$config['mid'] = $mid;
          	file_put_contents('config.json', json_encode($config));
          } elseif($data == 'run'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'start&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"حدد حساب",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"قم بتسجيل حساب اولا ⛔",
							'show_alert'=>1
						]);
            }
          }elseif($data == 'stop'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'stop&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"اختار الحساب",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"قم بتسجيل حساب اولا ⛔",
							'show_alert'=>1
						]);
            }
          }elseif($data == 'stopgr'){
            shell_exec('screen -S gr -X quit');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"تم الانتهاء من السحب",
						// 	'show_alert'=>1
						]);
						$for = $config['for'] != null ? $config['for'] : 'Select Account';
            $count = count(explode("\n", file_get_contents($for)));
						$bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                       [['text'=>'سحب من كلمات✨','callback_data'=>'search']],
                        [['text'=>'هاشتاج','callback_data'=>'hashtag'],['text'=>'📈 من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'Followers','callback_data'=>'followers'],['text'=>"Following",'callback_data'=>'following']],
                        [['text'=>"الحساب المحدد : $for",'callback_data'=>'for']],
                        [['text'=>'لسته يوزرات جديده ⚕️','callback_data'=>'newList'],['text'=>'لسته يوزرات سابقه ⚠️','callback_data'=>'append']],
                        [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']],
                    ]
                ])
            ]);
          } elseif($data == 'explore' and $chatId == $id ){
            exec('screen -dmS gr php explore.php');
          } elseif($data == 'status'){
					$status = '';
					foreach($accounts as $account => $ac){
						$c = explode(':', $account)[0];
						$x = exec('screen -S '.$c.' -Q select . ; echo $?');
						if($x == '0'){
				        $status .= "*$account* ~> _Working_\n";
				    } else {
				        $status .= "*$account* ~> _Stop_\n";
				    }
					}
					$bot->sendMessage([
							'chat_id'=>$chatId,
							'text'=>"حاله الحسابات : \n\n $status",
							'parse_mode'=>'markdown'
						]);
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
				} elseif($data == 'backakil'  and $chatId == $id ){
          	$bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "اهلا عزيزي ✔️
في الاسفل هي حساباتك الوهميه المسجله في الاداة",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'☬أضافه حساب وهمي جديد☬','callback_data'=>'login']],
                          [['text'=>'✦ طرق سحب اليوزرات ✦','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 💀','callback_data'=>'run'],['text'=>'ايقاف الصيد💀','callback_data'=>'stop']],
                          [['text'=>'حاله الحسابات ⚒','callback_data'=>'status'],['text'=>'قسم خاص ✔','callback_data'=>'statusakil']],
 [['text'=>' قناتي❗','url'=>'t.me/H5QQQ'],['text'=>'المطور❔','url'=>'t.me/AKIL22BOT']],
                      ]
                  ])
                  ]);		
						
						
		} elseif($data == 'oko1x'){
		$akil967 = file_get_contents("akil");
		system("cd akil1 ; screen -S nl$akil967 -X kill");
		file_put_contents("V1","✅");
		$loo1 =  file_get_contents("akil1/ID");
        $toook = file_get_contents("akil1/token");        
        system("cd akil1 ; screen -dmS nl$akil967 php bot.php");
        	$xx1 = file_get_contents("V1");
        
						  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم التفعيل ل : $loo1 ",

						]);

						
					
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 1
حاله التفعيل : $xx1 
ايدي الشخص : $loo1
توكن :  $toook ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo1x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko1x'],['text'=>"ايقاف ",'callback_data'=>'killx1']],
                  ]
                  ])
                  ]);
						
								
								} elseif($data == 'oko2x'){
								$akil967 = file_get_contents("akil");
		system("cd akil2 ; screen -S nl2$akil967 -X kill");
		file_put_contents("V2","✅");
		$loo2 =  file_get_contents("akil2/ID");
        $toook2 = file_get_contents("akil2/token");        
        system("cd akil2 ; screen -dmS nl2$akil967 php bot.php");
        
						  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم التفعيل ل : $loo2 ",

						]);

						
						$xz2 = file_get_contents("V2");
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 2
حاله التفعيل : $xz2 
ايدي الشخص : $loo2
توكن :  $toook2 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo2x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko2x'],['text'=>"ايقاف ",'callback_data'=>'killx2']],
                  ]
                  ])
                  ]);
						} elseif($data == 'oko3x'){
					$akil967 = file_get_contents("akil");
		system("cd akil3 ; screen -S nl3$akil967 -X kill");
		file_put_contents("V3","✅");
		$loo3 =  file_get_contents("akil3/ID");
        $toook3 = file_get_contents("akil3/token");        
        system("cd akil3 ; screen -dmS nl3$akil967 php bot.php");
        
						  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم التفعيل ل : $loo3 ",

						]);

						
						$xz3 = file_get_contents("V3");
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 3
حاله التفعيل : $xz3 
ايدي الشخص : $loo3
توكن :  $toook3 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo3x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko3x'],['text'=>"ايقاف ",'callback_data'=>'killx3']],
                  ]
                  ])
                  ]);
							} elseif($data == 'oko4x'){
							$akil967 = file_get_contents("akil");
		system("cd akil4 ; screen -S nl4$akil967 -X kill");
		file_put_contents("V4","✅");
		$loo4 =  file_get_contents("akil4/ID");
        $toook4 = file_get_contents("akil4/token");        
        system("cd akil4 ; screen -dmS nl4$akil967 php bot.php");
        
						  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم التفعيل ل : $loo4 ",

						]);

						
						$xz4 = file_get_contents("V4");
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 4
حاله التفعيل : $xz4
ايدي الشخص : $loo4
توكن :  $toook4 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo4x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko4x'],['text'=>"ايقاف ",'callback_data'=>'killx4']],
                  ]
                  ])
                  ]);                                   
                  
                                                       
                    } elseif($data == 'oko5x'){
                    $akil967 = file_get_contents("akil");
		system("cd akil5 ; screen -S nl5$akil967 -X kill");
		file_put_contents("V5","✅");
		$loo5 =  file_get_contents("akil5/ID");
        $toook5 = file_get_contents("akil5/token");        
        system("cd akil5 ; screen -dmS nl5$akil967 php bot.php");
        
						  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم التفعيل ل : $loo5 ",

						]);

						
						$xz5 = file_get_contents("V5");
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 5
حاله التفعيل : $xz5
ايدي الشخص : $loo5
توكن :  $toook5 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo5x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko5x'],['text'=>"ايقاف ",'callback_data'=>'killx5']],
                  ]
                  ])
                  ]);                  
                  
                                                                                                                                                
                      } elseif($data == 'oko6x'){
                      $akil967 = file_get_contents("akil");
		system("cd akil6 ; screen -S nl6$akil967 -X kill");
		file_put_contents("V6","✅");
		$loo6 =  file_get_contents("akil6/ID");
        $toook6 = file_get_contents("akil6/token");        
        system("cd akil6 ; screen -dmS nl6$akil967 php bot.php");
        
						  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم التفعيل ل : $loo6 ",

						]);

						
						$xz6 = file_get_contents("V7");
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 6
حاله التفعيل : $xz6
ايدي الشخص : $loo6
توكن :  $toook6 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo6x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko6x'],['text'=>"ايقاف ",'callback_data'=>'killx6']],
                  ]
                  ])
                  ]);                                              
                  
                  
		} elseif($data == 'killx6'){		
                  		$akil967 = file_get_contents("akil");	
     		file_put_contents("V6", "❌");
			$loo4 =  file_get_contents("akil6/ID");
			system("cd akil6 ; screen -S nl6$akil967 -X kill");
			
			  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم ايقاف التفعيل ل : $loo6 ",

						]);

						$xz6 = file_get_contents("V6");
				      $toook6 = file_get_contents("akil6/token");        
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 6
حاله التفعيل : $xz6
ايدي الشخص : $loo6
توكن :  $toook6 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo6x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko6x'],['text'=>"ايقاف ",'callback_data'=>'killx6']],
                  ]
                  ])
                  ]);                                
                                                                                                                                                                                                                                                                                                                                                                                             
              		} elseif($data == 'killx5'){		
                  		$akil967 = file_get_contents("akil");	
     		file_put_contents("V5", "❌");
			$loo5 =  file_get_contents("akil5/ID");
			system("cd akil5 ; screen -S nl5$akil967 -X kill");
			
			  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم ايقاف التفعيل ل : $loo5 ",

						]);

						$xz5 = file_get_contents("V5");
				      $toook5 = file_get_contents("akil5/token");        
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 5
حاله التفعيل : $xz5
ايدي الشخص : $loo5
توكن :  $toook5 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo5x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko5x'],['text'=>"ايقاف ",'callback_data'=>'killx5']],
                  ]
                  ])
                  ]);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
                  		} elseif($data == 'killx4'){		
                  		$akil967 = file_get_contents("akil");	
     		file_put_contents("V4", "❌");
			$loo4 =  file_get_contents("akil4/ID");
			system("cd akil4 ; screen -S nl4$akil967 -X kill");
			
			  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم ايقاف التفعيل ل : $loo4 ",

						]);

						$xz4 = file_get_contents("V4");
				      $toook4 = file_get_contents("akil4/token");        
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 4
حاله التفعيل : $xz4 
ايدي الشخص : $loo4
توكن :  $toook4 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo4x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko4x'],['text'=>"ايقاف ",'callback_data'=>'killx4']],
                  ]
                  ])
                  ]);                                                                      
										} elseif($data == 'killx3'){		
										$akil967 = file_get_contents("akil");	
     		file_put_contents("V3", "❌");
			$loo2 =  file_get_contents("akil3/ID");
			system("cd akil3 ; screen -S nl3$akil967 -X kill");
			
			  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم ايقاف التفعيل ل : $loo3 ",

						]);

						$xz3 = file_get_contents("V3");
				      $toook3 = file_get_contents("akil3/token");        
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 3
حاله التفعيل : $xz3 
ايدي الشخص : $loo3
توكن :  $toook3 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo3x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko3x'],['text'=>"ايقاف ",'callback_data'=>'killx3']],
                  ]
                  ])
                  ]);
								
									} elseif($data == 'killx2'){		
									$akil967 = file_get_contents("akil");	
     		file_put_contents("V2", "❌");
			$loo2 =  file_get_contents("akil2/ID");
			system("cd akil2 ; screen -S nl2$akil967 -X kill");
			
			  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم ايقاف التفعيل ل : $loo2 ",

						]);

						$xz2 = file_get_contents("V2");
				      $toook2 = file_get_contents("akil2/token");        
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 2
حاله التفعيل : $xz2 
ايدي الشخص : $loo2
توكن :  $toook2 ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo2x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko2x'],['text'=>"ايقاف ",'callback_data'=>'killx2']],
                  ]
                  ])
                  ]);
								
			} elseif($data == 'killx1'){			
			$akil967 = file_get_contents("akil");
     		file_put_contents("V1", "❌");
			$loo1 =  file_get_contents("akil1/ID");
			system("cd akil1 ; screen -S nl$akil967 -X kill");
			
			  $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "تم ايقاف التفعيل ل : $loo1 ",

						]);

						$xx1 = file_get_contents("V1");
						$bot->editMessageText([					
					'chat_id'=>$chatId,
                      'message_id'=>$mid,
                         'text'=> "البوت رقم 1
حاله التفعيل : $xz1 
ايدي الشخص : $loo1
توكن :  $toook ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo1x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko1x'],['text'=>"ايقاف ",'callback_data'=>'killx1']],
                  ]
                  ])
                  ]);
						
			
		} elseif($data == 'statusakil' and $chatId == $id){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "🔘كيف حالك @H5QQQ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'شرح المتاحات','callback_data'=>'akilx1']],
                          [['text'=>'رابط سحب متاح الهوتميل','callback_data'=>'akilx2']],
                          [['text'=>'قسم التفعيل','callback_data'=>'akilo1']],
                         
                          [['text'=>'نقل ملكيه البوت','callback_data'=>'akilx3']],
                          [['text'=>'ايديك','callback_data'=>'akilx4'],['text'=>'رجوع','callback_data'=>'back']],
 [['text'=>' قناتي❗','url'=>'t.me/H5QQQ'],['text'=>'المطور❔','url'=>'t.me/AKIL22BOT']],
                      ]
                  ])
                  ]);				
						
						
						                  } elseif($data == 'akilx1'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "اختراق المتاح :- اختراق حسابات انستغرام المتاحه هوه اختراق غير محدد وينطبق على  حسابات التي تتوفر فيها شروط معينه

 س / ماهو متاح وما هي فكره المتاح

ج /  عندما تنشى حساب انستكرام جديد 
يطلب منك ايميل  هنالك اشخاص تقوم بـ اضافه ايميل وهمي غير مربوط بالجهاز فـ هذه الحساب يسمى متاح 
او
حساب انستكرام مربوط ببريد ياهو او هوتميل لم يفتح صاحبه البريد لمدة سنه كامله
فلذالك قام الياهو او الهوتميل بحذف الحساب من قاعدة بياناته  لاجل توفير مساحه هنالك حسابات متاحه Gmail لكـن جيميل لا يحذف معلومات مستخدم
 في اي حاله كانت


اختراق المتاح :-  بكل سهوله و بساطة تقوم بي. تأكد من نوع متاح هل هول Gmail او hotmail او yahoo او maill اَو غيرها وتقوم بل دخول لي مواقع  انشاء حسابات مثل Gmail  تدخل اظافه حساب وتختار جيميل وتنشئ حساب جديد و تظيف البريد الإلكتروني الخاص بل حساب المتاح و تقوم بي عمل Rest  من الانستغرام و يصل رابط تغير كلمه سر الحساب

الي ميعرف شنو المتاح وشون يخترقه
@H5QQQ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
                  
											
												
													
														
															
																
						
				} elseif($data == 'akilx3'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> " - ارسل الأمر التالي الآن
/Change ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد نقل البوت ل,",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);			
																		
																			
																				
																					
																						
																							
																								
																									
																											
						} elseif($data == 'akilx2'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "https://signup.live.com/signup?lcid=1033&wa=wsignin1.0&rpsnv=13&ct=1504132238&rver=6.7.6640.0&wp=MBI_SSL&wreply=https%3A%2F%2Foutlook.live.com%2Fowa%2F%3Fnlp%3D1%26signup%3D1%26authRedirect%3Dtrue%26RpsCsrfState%3Df350c55d-4b3a-b9c7-ed28-dcdf2e9f47f7&id=292841&CBCXT=out&fl=wld&pcexp=false&cobrandid=90015&uaid=130c9ab91ce74ebd97397561ca52fe89&lic=1




اختراق هوتميل مختصر على تحديث القديم اذا تريدة ما يطلب رقم الهاتف بس حوله على الجزائر أو المملكة العربية السعودية ضيف أي رقم عشوائي بعدين أدخل الحروف التي تراها استخدام كابتل 



                     @H5QQQ
                     🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          ]
                  ])
                  ]);
               
						} elseif($data == 'akilo1'){
											
					$xz1 = file_get_contents("V1");				
					$xz2 = file_get_contents("V2");					
					$xz3 = file_get_contents("V3");					
					$xz4 = file_get_contents("V4");			
					$xz5 = file_get_contents("V5");					
					$xz6 = file_get_contents("V6");										         
	          $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "قسم التفعيل",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                          [['text'=>"بوت رقم 1 : $xz1 ",'callback_data'=>'ooo1'],['text'=>"بوت رقم 3 : $xz3 ",'callback_data'=>'ooo3']],
                          [['text'=>"بوت رقم 2 : $xz2 ",'callback_data'=>'ooo2'],['text'=>"بوت رقم 4 : $xz4 ",'callback_data'=>'ooo4']],
                          [['text'=>"بوت رقم 5 : $xz5 ",'callback_data'=>'ooo5'],['text'=>"بوت رقم 6 : $xz6 ",'callback_data'=>'ooo6']],
                          [['text'=>'رجوع','callback_data'=>'statusakil']],
                          
                          
                          
                          ]
                  ])
                  ]);
                       	} elseif($data == 'ooo6'){
                  
                    $idbo6 = file_get_contents('akil6/ID');
                    	$xz6 = file_get_contents("V6");
                  
                  
                   $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "البوت رقم 6
حاله التفعيل : $xz6
ايدي الشخص : $idbot6
توكن :  $toook6    ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo6x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko6x'],['text'=>"ايقاف ",'callback_data'=>'killx6']],
                  ]
                  ])
                  ]);
                  
                  
                  
     	} elseif($data == 'ooo5'){
                  
                    $idbo5 = file_get_contents('akil5/ID');
                    	$xz5 = file_get_contents("V5");
                  
                  
                   $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "البوت رقم 5
حاله التفعيل : $xz5
ايدي الشخص : $idbot5
توكن :  $toook5   ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo5x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko5x'],['text'=>"ايقاف ",'callback_data'=>'killx5']],
                  ]
                  ])
                  ]);
                  
                  
                  	} elseif($data == 'ooo4'){
                  
                    $idbo4 = file_get_contents('akil4/ID');
                    	$xz4 = file_get_contents("V4");
                  
                  
                   $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "البوت رقم 4
حاله التفعيل : $xz4 
ايدي الشخص : $idbot4
توكن :  $toook4    ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo4x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko4x'],['text'=>"ايقاف ",'callback_data'=>'killx4']],
                  ]
                  ])
                  ]);
                  
                  
                  
                  
                  
                  	} elseif($data == 'ooo3'){
                  
                    $idbot3 = file_get_contents('akil3/ID');
                    	$xz3 = file_get_contents("V3");
                  
                  
                   $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "البوت رقم 3
حاله التفعيل : $xz3 
ايدي الشخص : $idbot3
توكن :  $toook3    ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo3x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko3x'],['text'=>"ايقاف ",'callback_data'=>'killx3']],
                  ]
                  ])
                  ]);
                  
                                    	} elseif($data == 'ooo2'){
                  
                    $idbot2 = file_get_contents('akil2/ID');
                    	$xz2 = file_get_contents("V2");
                  
                  
                   $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "البوت رقم 2
حاله التفعيل : $xz2 
ايدي الشخص : $idbot2
توكن :  $toook2    ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo2x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko2x'],['text'=>"ايقاف ",'callback_data'=>'killx2']],
                  ]
                  ])
                  ]);
                  
                  
                  	} elseif($data == 'ooo1'){
                  
                    $idbot1 = file_get_contents('akil1/ID');
                    	$xz1 = file_get_contents("V1");
                  
                  
                   $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "البوت رقم 1
حاله التفعيل : $xz1 
ايدي الشخص : $idbot1
توكن :  $toook    ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>"رجوع",'callback_data'=>'akilo1'],['text'=>"اضف ايدي شخص او استبدله",'callback_data'=>'ooo1x']],
                      [['text'=>"تفعيل ",'callback_data'=>'oko1x'],['text'=>"ايقاف ",'callback_data'=>'killx1']],
                  ]
                  ])
                  ]);


	} elseif($data == 'ooo1x'){
	

      $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 1
ارسل الأمر التالي الآن
/akil1 ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد تفعيل  البوت له",

						]);

   

                  
                  	} elseif($data == 'ooo2x'){
	

      $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 2
ارسل الأمر التالي الآن
/akil2 ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد تفعيل  البوت له",

						]);

   

                  
                  
	} elseif($data == 'ooo3x'){
	

      $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 3
ارسل الأمر التالي الآن
/akil3 ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد تفعيل  البوت له",

						]);

                  		
						
	} elseif($data == 'ooo4x'){
	

      $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 4
ارسل الأمر التالي الآن
/akil4 ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد تفعيل  البوت له",

						]);

                  		
                  		
							} elseif($data == 'ooo5x'){
	

      $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 5
ارسل الأمر التالي الآن
/akil5 ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد تفعيل  البوت له",

						]);

                  		
							} elseif($data == 'ooo6x'){
	

      $bot->sendMessage([
                      'chat_id'=>$chatId,
                     'text'=> "
بوت رقم 6
ارسل الأمر التالي الآن
/akil6 ID
- استبدل كلمة ID ب ايدي الشخص الذي تريد تفعيل  البوت له",

						]);

                  		
				} elseif($data == 'back'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                     'text'=> "اهلا عزيزي ✔️
في الاسفل هي حساباتك الوهميه المسجله في الاداة",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'☬أضافه حساب وهمي جديد☬','callback_data'=>'login']],
                          [['text'=>'✦ طرق سحب اليوزرات ✦','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 💀','callback_data'=>'run'],['text'=>'ايقاف الصيد💀','callback_data'=>'stop']],
                          [['text'=>'حاله الحسابات ⚒','callback_data'=>'status'],['text'=>'قسم خاص ✔','callback_data'=>'statusakil']],
 [['text'=>' قناتي❗','url'=>'t.me/H5QQQ'],['text'=>'المطور❔','url'=>'t.me/AKIL22BOT']],
                      ]
                  ])
                  ]);
          } else {
          	$data = explode('&',$data);
          	if($data[0] == 'del'){

          		unset($accounts[$data[1]]);
          		file_put_contents('accounts.json', json_encode($accounts));
              $keyboard = ['inline_keyboard'=>[
							[['text'=>"ضيف وهمي جديد ➕",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"تسجيل الخروج",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                    'text'=>"اهلا عزيزي ✔️ في الاسفل هي حساباتك الوهميه المسجله في الاداة",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
          	} elseif($data[0] == 'moveList'){
          	  file_put_contents('list', $data[1]);
          	  $keyboard = [];
          	  foreach ($accounts as $account => $v) {
                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'moveListTo&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"اختر الحساب الذي تريد نقل اللسته اليه",
                  'reply_markup'=>json_encode($keyboard)
	              ]);
          	} elseif($data[0] == 'moveListTo'){
          	  $keyboard = [];
          	  file_put_contents($data[1], file_get_contents(file_get_contents('list')));
          	  unlink(file_get_contents('list'));
          	  $keyboard['inline_keyboard'][] = [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']];
          	  $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"تم نقل اللسته الى الحساب  ✅".$data[1],
                  'reply_markup'=>json_encode($keyboard)
	              ]);
          	} elseif($data[0] == 'forg'){
          	  $config['for'] = $data[1];
          	  file_put_contents('config.json',json_encode($config));
              $for = $config['for'] != null ? $config['for'] : 'Select';
              $count = count(file_get_contents($for));
              $bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                            [['text'=>'سحب من كلمات✨','callback_data'=>'search']],
                        [['text'=>'هاشتاج','callback_data'=>'hashtag'],['text'=>'📈 من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'Followers','callback_data'=>'followers'],['text'=>"Following",'callback_data'=>'following']],
                        [['text'=>"الحساب المحدد : $for",'callback_data'=>'for']],
                        [['text'=>'لسته يوزرات جديده ⚕️','callback_data'=>'newList'],['text'=>'لسته يوزرات سابقه ⚠️','callback_data'=>'append']],
                        [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']],
                    ]
                ])
            ]);
          	} elseif($data[0] == 'start'){
          	  file_put_contents('screen', $data[1]);
          	  $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                       'text'=> "اهلا بك مره اخرى عزيزي ✔️
اختر ما تريده من الاسفل 👇",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'☬أضافه حساب وهمي جديد☬','callback_data'=>'login']],
                          [['text'=>'✦ طرق سحب اليوزرات ✦','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 💀','callback_data'=>'run'],['text'=>'ايقاف الصيد💀','callback_data'=>'stop']],
                          [['text'=>'حاله الحسابات ⚒','callback_data'=>'status'],['text'=>'قسم خاص ✔','callback_data'=>'statusakil']],
 [['text'=>' قناتي❗','url'=>'t.me/H5QQQ'],['text'=>'المطور❔','url'=>'t.me/AKIL22BOT']],
                      ]
                  ])
                  ]);
              exec('screen -dmS '.explode(':',$data[1])[0].' php start.php');
              
              $zz99 = exec('screen -dmS '.explode(':',$data[1])[0].' php start.php');
               file_put_contents("Vjj4",$zz99);

              $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"*بدء الصيد.*\n Account: `".explode(':',$data[1])[0].'`',
                'parse_mode'=>'markdown'
              ]);
          	} elseif($data[0] == 'stop'){
          	  $bot->editMessageText([
                      'chat_id'=>$chatId,
                      'message_id'=>$mid,
                      'text'=>"اهلا بك مره اخرى عزيزي ✔️
اختر ما تريده من الاسفل 👇",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'☬أضافه حساب وهمي جديد☬','callback_data'=>'login']],
                          [['text'=>'✦ طرق سحب اليوزرات ✦','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 💀','callback_data'=>'run'],['text'=>'ايقاف الصيد💀','callback_data'=>'stop']],
                          [['text'=>'حاله الحسابات ⚒','callback_data'=>'status'],['text'=>'قسم خاص ✔','callback_data'=>'statusakil']],
 [['text'=>' قناتي❗','url'=>'t.me/H5QQQ'],['text'=>'المطور❔','url'=>'t.me/AKIL22BOT']],
                      ]
                    ])
                  ]);
              exec('screen -S '.explode(':',$data[1])[0].' -X quit');
          	}
          }
			}
		}
	};
	
	
			
	
$bot = new EzTG(array('throw_telegram_errors'=>false,'token' => $token, 'callback' => $callback));
} catch(Exception $e){
	echo $e->getMessage().PHP_EOL;
	sleep(1);
}
